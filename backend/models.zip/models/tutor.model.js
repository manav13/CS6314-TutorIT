const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const tutorSchema = new Schema({

    name: { type: String },
    about: { type: String },
    image: { type: String },
    courses: [
        { type: String }
    ],
    rating: { type: String }

});

module.exports = mongoose.model("Tutor", tutorSchema);