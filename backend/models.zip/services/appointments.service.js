const service = {};
const Appointment = require('../models/appointments.model');
const Authentication = require('../models/authentication.model');
const Tutor = require('../models/tutor.model');
const User = require('../models/user.model');
const utility = require('../core/utility')
const randToken = require('rand-token');
const mongoose = require('mongoose');

service.addAppointment = async (req, res, next) => {
    const appointment = new Appointment({
        courseCode: req.body.courseCode,
        tutorId: req.body.tutorId,
        appointmentDate: req.body.appointmentDate,
        appointmentLocation: req.body.appointmentLocation,
        appointmentTime: req.body.appointmentTime
    });
    const response = await appointment.save();
    res.send(response);
}

service.updateAppointment = async (req, res, next) => {
    // let id = req.params.id;
    const response = await Appointment.findOneAndUpdate({ _id: req.params.id }, {
        $set: req.body  
    });
    res.send(response);
}

service.deleteAppointment = async (req, res, next) => {
    const response = await Appointment.remove({ _id: req.paramns.id }, (err) => {
        if (err) res.json(err);
    });
    res.send(response);
}

module.exports = service;